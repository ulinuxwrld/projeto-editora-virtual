# src/routes/main_routes.py
from flask import Blueprint, render_template
from flask_login import login_required, current_user

main_bp = Blueprint("main_routes", __name__, template_folder="../templates/main")

@main_bp.route("/")
@login_required
def index():
    # Esta será a página principal após o login
    # Poderia ser um dashboard para selecionar páginas, etc.
    return render_template("index.html", title="Página Principal", username=current_user.username)

