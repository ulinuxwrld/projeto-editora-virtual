# -*- coding: utf-8 -*-
"""
Rotas para a funcionalidade de compilação personalizada de PDFs.
Permite que os usuários selecionem páginas de várias apostilas fonte carregadas
para criar um novo PDF personalizado.
"""
import os
import json
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, send_from_directory
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from src.extensions import db
from src.models.uploaded_workbook import UploadedWorkbook
from src.models.page import UserWorkbook # CORRIGIDO: Importar UserWorkbook de src.models.page
from src.pdf_utils import get_pdf_bookmarks, extract_pages_from_pdf, merge_pdfs

custom_compiler_bp = Blueprint("custom_compiler", __name__, url_prefix="/custom_compiler", template_folder="../templates/custom_compiler")

# Diretório para salvar os PDFs compilados temporariamente ou permanentemente
COMPILED_PDF_DIR_RELATIVE = "compiled_pdfs"

@custom_compiler_bp.route("/select_and_compile", methods=["GET", "POST"])
@login_required
def select_and_compile():
    if request.method == "POST":
        # Lógica para processar as seleções e gerar o PDF
        form_data = request.form
        output_filename = form_data.get("output_filename", "apostila_personalizada").strip()
        if not output_filename:
            flash("Por favor, forneça um nome para o arquivo PDF final.", "danger")
            return redirect(url_for("custom_compiler.select_and_compile"))
        
        # Garante que o nome do arquivo termine com .pdf
        if not output_filename.lower().endswith(".pdf"):
            output_filename += ".pdf"
        output_filename = secure_filename(output_filename)

        pdf_writers_to_merge = []
        ordered_selections_summary = [] # Para mostrar no flash ou log

        selected_workbook_ids = request.form.getlist("workbook_ids[]")
        page_selections_str = request.form.getlist("page_selections[]")

        if not selected_workbook_ids or len(selected_workbook_ids) != len(page_selections_str):
            flash("Erro nos dados de seleção. Tente novamente.", "danger")
            source_workbooks = UploadedWorkbook.query.order_by(UploadedWorkbook.title).all()
            return render_template("select_and_compile_form.html", 
                                     title="Compilar Apostila Personalizada", 
                                     source_workbooks=source_workbooks)

        for i, workbook_id_str in enumerate(selected_workbook_ids):
            page_range_for_workbook = page_selections_str[i].strip()
            if not page_range_for_workbook: 
                continue
            
            try:
                workbook_id = int(workbook_id_str)
                source_workbook = UploadedWorkbook.query.get(workbook_id)
                if not source_workbook:
                    flash(f"Apostila fonte com ID {workbook_id} não encontrada.", "warning")
                    continue

                source_pdf_abs_path = os.path.join(current_app.instance_path, source_workbook.filepath_relative)
                
                extracted_writer = extract_pages_from_pdf(source_pdf_abs_path, page_range_for_workbook)
                if extracted_writer and extracted_writer.pages: 
                    pdf_writers_to_merge.append(extracted_writer)
                    ordered_selections_summary.append(f"{source_workbook.title}: Páginas {page_range_for_workbook}")
                else:
                    flash(f"Não foi possível extrair as páginas 	'{page_range_for_workbook}	' da apostila 	'{source_workbook.title}	'. Verifique a seleção.", "warning")
            
            except ValueError:
                flash(f"ID de apostila inválido: {workbook_id_str}", "warning")
                continue
            except Exception as e:
                flash(f"Erro ao processar a apostila ID {workbook_id_str}: {e}", "danger")
                continue
        
        if not pdf_writers_to_merge:
            flash("Nenhuma página foi selecionada ou extraída com sucesso para compilar.", "warning")
            source_workbooks = UploadedWorkbook.query.order_by(UploadedWorkbook.title).all()
            return render_template("select_and_compile_form.html", 
                                     title="Compilar Apostila Personalizada", 
                                     source_workbooks=source_workbooks)

        compiled_pdf_dir_abs = os.path.join(current_app.instance_path, COMPILED_PDF_DIR_RELATIVE)
        os.makedirs(compiled_pdf_dir_abs, exist_ok=True)
        final_pdf_abs_path = os.path.join(compiled_pdf_dir_abs, output_filename)

        merge_success = merge_pdfs(pdf_writers_to_merge, final_pdf_abs_path)

        if merge_success:
            flash(f"Apostila personalizada 	'{output_filename}	' gerada com sucesso!", "success")
            return redirect(url_for("custom_compiler.download_compiled_pdf", filename=output_filename))
        else:
            flash("Erro ao gerar o PDF final compilado.", "danger")

    source_workbooks = UploadedWorkbook.query.order_by(UploadedWorkbook.title).all()
    for wb in source_workbooks:
        if wb.bookmarks_json:
            try:
                wb.parsed_bookmarks = json.loads(wb.bookmarks_json)
            except json.JSONDecodeError:
                wb.parsed_bookmarks = []
        else:
            wb.parsed_bookmarks = []
            
    return render_template("select_and_compile_form.html", 
                             title="Compilar Apostila Personalizada", 
                             source_workbooks=source_workbooks)


@custom_compiler_bp.route("/download_compiled_pdf/<filename>")
@login_required
def download_compiled_pdf(filename):
    directory = os.path.join(current_app.instance_path, COMPILED_PDF_DIR_RELATIVE)
    try:
        return send_from_directory(directory, filename, as_attachment=True)
    except FileNotFoundError:
        flash("Arquivo PDF compilado não encontrado.", "danger")
        return redirect(url_for("custom_compiler.select_and_compile"))

