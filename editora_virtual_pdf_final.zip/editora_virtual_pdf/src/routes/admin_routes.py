# -*- coding: utf-8 -*-
"""
Rotas administrativas para gerenciamento de apostilas fonte.
"""
import os
import json
import uuid # Adicionado para nomes de arquivo únicos
import time # Adicionado para nomes de arquivo únicos
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user 
from werkzeug.utils import secure_filename
from pypdf import PdfReader

from src.extensions import db
from src.models.uploaded_workbook import UploadedWorkbook
from src.pdf_utils import get_pdf_bookmarks 

admin_bp = Blueprint("admin", __name__, url_prefix="/admin", template_folder="../templates/admin")

UPLOAD_FOLDER_RELATIVE = "source_pdfs"
ALLOWED_EXTENSIONS = {"pdf"}

def allowed_file(filename):
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@admin_bp.route("/upload_workbook", methods=["GET", "POST"])
@login_required
def upload_workbook():
    # if not current_user.is_admin:
    #     flash("Acesso não autorizado.", "danger")
    #     return redirect(url_for("main_routes.index"))

    if request.method == "POST":
        if "pdf_file" not in request.files:
            flash("Nenhum arquivo selecionado.", "warning")
            return redirect(request.url)
        
        file = request.files["pdf_file"]
        title = request.form.get("title", "").strip()

        if not title:
            flash("O título da apostila é obrigatório.", "warning")
            return redirect(request.url)

        if file.filename == "":
            flash("Nenhum arquivo selecionado.", "warning")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            original_filename = secure_filename(file.filename)
            name_part, ext_part = os.path.splitext(original_filename)
            # Gerar nome de arquivo único para armazenamento
            unique_suffix = uuid.uuid4().hex[:8] + "_" + str(int(time.time()))
            filename_on_server = f"{name_part}_{unique_suffix}{ext_part}"
            
            upload_folder_abs = os.path.join(current_app.instance_path, UPLOAD_FOLDER_RELATIVE)
            os.makedirs(upload_folder_abs, exist_ok=True)
            
            filepath_abs = os.path.join(upload_folder_abs, filename_on_server)
            filepath_relative_to_instance = os.path.join(UPLOAD_FOLDER_RELATIVE, filename_on_server)

            # Verificar se já existe um arquivo com este nome único gerado (extremamente improvável, mas seguro)
            if os.path.exists(filepath_abs):
                flash("Erro ao gerar nome de arquivo único. Tente novamente.", "danger")
                return redirect(request.url)

            try:
                file.save(filepath_abs)

                reader = PdfReader(filepath_abs)
                total_pages = len(reader.pages)
                bookmarks = get_pdf_bookmarks(filepath_abs) 
                bookmarks_json_str = json.dumps(bookmarks) if bookmarks else None

                new_uploaded_workbook = UploadedWorkbook(
                    title=title,
                    original_filename=original_filename, # Salva o nome original do arquivo
                    filepath_relative=filepath_relative_to_instance, # Salva o caminho com nome único
                    total_pages=total_pages,
                    bookmarks_json=bookmarks_json_str,
                    uploaded_by_user_id=current_user.id
                )
                db.session.add(new_uploaded_workbook)
                db.session.commit()
                flash(f"Apostila 	'{title}'	 carregada com sucesso como 	'{filename_on_server}'!", "success")
                return redirect(url_for("admin.list_uploaded_workbooks"))

            except Exception as e:
                db.session.rollback()
                flash(f"Erro ao processar o arquivo PDF: {e}", "danger")
                if os.path.exists(filepath_abs):
                    os.remove(filepath_abs)
                return redirect(request.url)
        else:
            flash("Formato de arquivo não permitido. Apenas PDFs são aceitos.", "warning")
            return redirect(request.url)

    return render_template("upload_workbook_form.html", title="Carregar Nova Apostila Fonte")

@admin_bp.route("/uploaded_workbooks")
@login_required
def list_uploaded_workbooks():
    # if not current_user.is_admin:
    #     flash("Acesso não autorizado.", "danger")
    #     return redirect(url_for("main_routes.index"))
        
    workbooks = UploadedWorkbook.query.order_by(UploadedWorkbook.uploaded_at.desc()).all()
    return render_template("list_uploaded_workbooks.html", title="Apostilas Fonte Carregadas", workbooks=workbooks)


@admin_bp.route("/delete_uploaded_workbook/<int:workbook_id>", methods=["POST"])
@login_required
def delete_uploaded_workbook(workbook_id):
    # if not current_user.is_admin:
    #     flash("Acesso não autorizado.", "danger")
    #     return redirect(url_for("admin.list_uploaded_workbooks"))

    workbook_to_delete = UploadedWorkbook.query.get_or_404(workbook_id)
    
    # Idealmente, verificar permissões aqui (ex: se current_user.is_admin)

    try:
        filepath_abs = os.path.join(current_app.instance_path, workbook_to_delete.filepath_relative)

        if os.path.exists(filepath_abs):
            os.remove(filepath_abs)
            # flash(f"Arquivo PDF 	'{workbook_to_delete.original_filename}'	 (salvo como 	'{os.path.basename(workbook_to_delete.filepath_relative)}'	) removido do servidor.", "info")
        # else:
            # flash(f"Arquivo PDF 	'{os.path.basename(workbook_to_delete.filepath_relative)}'	 não encontrado no servidor, mas o registro será removido.", "warning")

        db.session.delete(workbook_to_delete)
        db.session.commit()
        flash(f"Apostila fonte 	'{workbook_to_delete.title}'	 foi excluída com sucesso.", "success")
    
    except Exception as e:
        db.session.rollback()
        flash(f"Erro ao excluir a apostila fonte: {e}", "danger")

    return redirect(url_for("admin.list_uploaded_workbooks"))

