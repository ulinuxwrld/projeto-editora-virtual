# src/routes/workbook_routes.py
import os
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, send_from_directory
from flask_login import login_required, current_user
from fpdf import FPDF, FPDFException
from src.extensions import db
from src.models.page import Page, UserWorkbook
import html 
import re 

workbook_bp = Blueprint("workbook", __name__, template_folder="../templates/workbook")

PDF_DIR_RELATIVE = "pdfs" # Relativo à pasta instance

class MyFPDF(FPDF):
    def header(self):
        pass 

    def footer(self):
        self.set_y(-15)
        font_family_to_try = "NotoSansCJK"
        font_style_to_try = "I"
        font_key_to_check = font_family_to_try.lower() + font_style_to_try.lower()

        try:
            if font_key_to_check in self.fonts:
                self.set_font(font_family_to_try, font_style_to_try, 8)
            else:
                self.set_font("Arial", "I", 8) # Fallback para Arial Italic
        except FPDFException:
            current_family = self.font_family if self.font_family else "Helvetica"
            try:
                self.set_font(current_family, "I", 8)
            except FPDFException:
                self.set_font(current_family, "", 8) 
        self.cell(0, 10, f"Página {self.page_no()}/{{nb}}", 0, 0, "C")

@workbook_bp.route("/create", methods=["GET", "POST"])
@login_required
def create_workbook():
    pages = Page.query.order_by(Page.subject, Page.grade_level, Page.title).all()
    if not pages:
        if Page.query.count() == 0:
            flash("Nenhuma página de conteúdo encontrada. Você pode popular com exemplos.", "info")
            return redirect(url_for("workbook.populate_sample_pages"))
        else:
            flash("Nenhuma página de conteúdo cadastrada.", "warning")

    if request.method == "POST":
        selected_page_ids_str = request.form.getlist("page_ids")
        workbook_title = request.form.get("workbook_title", "Minha Apostila Personalizada")

        if not selected_page_ids_str:
            flash("Por favor, selecione ao menos uma página para sua apostila.", "warning")
            return render_template("create_workbook.html", title="Criar Apostila", pages=pages, current_user=current_user, Page=Page)

        selected_page_ids = [int(id_str) for id_str in selected_page_ids_str]
        selected_pages_from_db = Page.query.filter(Page.id.in_(selected_page_ids)).all()
        ordered_selected_pages = sorted(selected_pages_from_db, key=lambda p: selected_page_ids.index(p.id))

        pdf = MyFPDF()
        pdf.alias_nb_pages()
        
        font_noto_name = "NotoSansCJK"
        font_noto_regular_path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
        font_noto_bold_path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
        font_noto_italic_path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Italic.ttc"

        pdf_font_family = "Arial"

        try:
            if os.path.exists(font_noto_regular_path):
                pdf.add_font(font_noto_name, "", font_noto_regular_path, uni=True)
                pdf_font_family = font_noto_name
                if os.path.exists(font_noto_bold_path):
                    pdf.add_font(font_noto_name, "B", font_noto_bold_path, uni=True)
                if os.path.exists(font_noto_italic_path):
                    pdf.add_font(font_noto_name, "I", font_noto_italic_path, uni=True)
            # Não vamos mais dar flash sobre fontes aqui para não poluir a interface
            # else:
            #     flash(f"Fonte {font_noto_regular_path} não encontrada. Usando Arial.", "warning")
        except RuntimeError as e:
            # flash(f"Erro ao carregar fonte {font_noto_name}: {e}. Usando Arial.", "warning")
            pass # Silencioso, fallback para Arial já está em vigor
            
        pdf.set_title(workbook_title)
        pdf.set_auto_page_break(auto=True, margin=15)

        for i, page_item in enumerate(ordered_selected_pages):
            pdf.add_page()
            
            try:
                if pdf_font_family == font_noto_name and (font_noto_name.lower() + "b") in pdf.fonts:
                    pdf.set_font(font_noto_name, "B", 16)
                else:
                    pdf.set_font("Arial", "B", 16)
            except FPDFException:
                pdf.set_font("Arial", "B", 16)
            pdf.cell(0, 10, page_item.title, 0, 1, "C")
            pdf.ln(5)
            
            try:
                if pdf_font_family == font_noto_name and (font_noto_name.lower() + "") in pdf.fonts:
                    pdf.set_font(font_noto_name, "", 12)
                else:
                    pdf.set_font("Arial", "", 12)
            except FPDFException:
                pdf.set_font("Arial", "", 12)
            
            content_html = page_item.content
            decoded_content = html.unescape(content_html)
            content_text_no_img = re.sub(r"<img[^>]*>", "[Imagem removida]", decoded_content)
            
            try:
                pdf.write_html(content_text_no_img)
            except Exception as e:
                pdf.multi_cell(0, 10, f"Erro ao renderizar HTML: {e}. Conteúdo: {content_text_no_img[:200]}...")

        pdf_filename = f"user_workbook_{current_user.id}_{UserWorkbook.query.count() + 1}_{int(os.times()[4] * 1000)}.pdf"
        pdf_dir_abs = os.path.join(current_app.instance_path, PDF_DIR_RELATIVE) 
        os.makedirs(pdf_dir_abs, exist_ok=True)
        pdf_full_path = os.path.join(pdf_dir_abs, pdf_filename)

        try:
            pdf.output(pdf_full_path, "F")
        except Exception as e:
            flash(f"Erro ao salvar o PDF: {e}", "danger")
            return render_template("create_workbook.html", title="Criar Apostila", pages=pages, current_user=current_user, Page=Page)

        new_workbook = UserWorkbook(
            user_id=current_user.id,
            title=workbook_title,
            selected_page_ids=",".join(selected_page_ids_str),
            pdf_file_path=os.path.join(PDF_DIR_RELATIVE, pdf_filename) 
        )
        db.session.add(new_workbook)
        db.session.commit()

        flash(f"Apostila 	'{workbook_title}'	 criada e PDF gerado com sucesso!", "success")
        return redirect(url_for("workbook.view_workbook", workbook_id=new_workbook.id))

    return render_template("create_workbook.html", title="Criar Nova Apostila", pages=pages, current_user=current_user, Page=Page)

@workbook_bp.route("/view/<int:workbook_id>")
@login_required
def view_workbook(workbook_id):
    workbook = UserWorkbook.query.get_or_404(workbook_id)
    if workbook.user_id != current_user.id:
        flash("Você não tem permissão para ver esta apostila.", "danger")
        return redirect(url_for("workbook.my_workbooks")) # Redireciona para a lista do usuário
    return render_template("view_workbook.html", title=workbook.title, workbook=workbook, Page=Page)

@workbook_bp.route("/download_pdf/<int:workbook_id>")
@login_required
def download_pdf(workbook_id):
    workbook = UserWorkbook.query.get_or_404(workbook_id)
    if workbook.user_id != current_user.id:
        flash("Você não tem permissão para baixar este PDF.", "danger")
        return redirect(url_for("workbook.my_workbooks"))
    
    if not workbook.pdf_file_path:
        flash("Caminho do PDF não encontrado para esta apostila.", "danger")
        return redirect(url_for("workbook.view_workbook", workbook_id=workbook.id))

    abs_pdf_path = os.path.join(current_app.instance_path, workbook.pdf_file_path)
    if not os.path.exists(abs_pdf_path):
        flash(f"Arquivo PDF não encontrado no servidor. Tente gerar novamente ou contate o suporte.", "danger")
        # Potencialmente, limpar o pdf_file_path do DB se o arquivo não existe mais
        # workbook.pdf_file_path = None
        # db.session.commit()
        return redirect(url_for("workbook.view_workbook", workbook_id=workbook.id))

    directory = os.path.dirname(abs_pdf_path)
    filename = os.path.basename(abs_pdf_path)
    return send_from_directory(directory, filename, as_attachment=True)


@workbook_bp.route("/my_workbooks")
@login_required
def my_workbooks():
    workbooks = UserWorkbook.query.filter_by(user_id=current_user.id).order_by(UserWorkbook.created_at.desc()).all()
    return render_template("my_workbooks.html", title="Minhas Apostilas", workbooks=workbooks)

@workbook_bp.route("/simulate_purchase/<int:workbook_id>", methods=["GET", "POST"]) 
@login_required
def simulate_purchase(workbook_id):
    workbook = UserWorkbook.query.get_or_404(workbook_id)
    if workbook.user_id != current_user.id:
        flash("Você não tem permissão para modificar esta apostila.", "danger")
        return redirect(url_for("workbook.my_workbooks"))

    if workbook.is_purchased:
        flash("Esta apostila já foi adquirida.", "info")
        return redirect(url_for("workbook.view_workbook", workbook_id=workbook.id))

    workbook.is_purchased = True
    db.session.commit()
    flash(f"Compra da apostila 	'{workbook.title}'	 simulada com sucesso!", "success")
    return redirect(url_for("workbook.view_workbook", workbook_id=workbook.id))


@workbook_bp.route("/populate_sample_pages")
@login_required
def populate_sample_pages():
    if Page.query.count() == 0:
        sample_data = [
            Page(title="Matemática: Adição Simples", subject="Matemática", grade_level="1º Ano", 
                 content=	'<h1>Adição Simples</h1><p>Bem-vindo à sua primeira lição de matemática! Adição é juntar quantidades.</p><p>Exemplo: 1 maçã + 1 maçã = 2 maçãs.</p><p><img src="https://i.imgur.com/0SWHG6A.png" alt="Maçãs" width="100"></p>	'),
            Page(title="Português: As Vogais", subject="Português", grade_level="1º Ano", 
                 content=	'<h1>As Vogais</h1><p>As vogais são A, E, I, O, U.</p><p>Vamos praticar: <strong>A</strong>belha, <strong>E</strong>lefante, <strong>I</strong>greja, <strong>O</strong>velha, <strong>U</strong>va.</p>	'),
            Page(title="Ciências: O Ciclo da Água", subject="Ciências", grade_level="2º Ano", 
                 content=	'<h1>O Ciclo da Água</h1><p>A água está sempre em movimento!</p><ol><li>Evaporação</li><li>Condensação</li><li>Precipitação</li><li>Coleta</li></ol>	'),
            Page(title="História: Descobrimento do Brasil", subject="História", grade_level="3º Ano", 
                 content=	'<h1>Descobrimento do Brasil</h1><p>Em 1500, Pedro Álvares Cabral chegou ao Brasil.</p><p>Os povos indígenas já viviam aqui.</p>	'),
            Page(title="Geografia: Pontos Cardeais", subject="Geografia", grade_level="3º Ano", 
                 content=	'<h1>Pontos Cardeais</h1><p>Norte (N), Sul (S), Leste (L ou E), Oeste (O ou W).</p><p>O sol nasce no Leste e se põe no Oeste.</p>	')
        ]
        db.session.bulk_save_objects(sample_data)
        db.session.commit()
        flash("Páginas de exemplo populadas no banco de dados!", "success")
    else:
        flash("Páginas de exemplo já existem no banco.", "info")
    return redirect(url_for("workbook.create_workbook"))

@workbook_bp.route("/delete_workbook/<int:workbook_id>", methods=["POST"])
@login_required
def delete_workbook(workbook_id):
    workbook_to_delete = UserWorkbook.query.get_or_404(workbook_id)

    if workbook_to_delete.user_id != current_user.id:
        flash("Você não tem permissão para excluir esta apostila.", "danger")
        return redirect(url_for("workbook.my_workbooks"))

    try:
        # Caminho absoluto para o arquivo PDF
        if workbook_to_delete.pdf_file_path:
            filepath_abs = os.path.join(current_app.instance_path, workbook_to_delete.pdf_file_path)
            # Excluir o arquivo físico
            if os.path.exists(filepath_abs):
                os.remove(filepath_abs)
                # flash(f"Arquivo PDF 	'{os.path.basename(workbook_to_delete.pdf_file_path)}'	 removido do servidor.", "info") # Opcional, pode poluir
            # else:
                # flash(f"Arquivo PDF 	'{os.path.basename(workbook_to_delete.pdf_file_path)}'	 não encontrado no servidor.", "warning") # Opcional
        
        # Excluir o registro do banco de dados
        db.session.delete(workbook_to_delete)
        db.session.commit()
        flash(f"Apostila 	'{workbook_to_delete.title}'	 foi excluída com sucesso.", "success")
    
    except Exception as e:
        db.session.rollback()
        flash(f"Erro ao excluir a apostila: {e}", "danger")

    return redirect(url_for("workbook.my_workbooks"))

