# -*- coding: utf-8 -*-
"""
Utilitários para manipulação de arquivos PDF.

Este módulo fornecerá funções para:
- Ler arquivos PDF.
- Extrair informações sobre bookmarks (capítulos) e seus números de página.
- Extrair páginas específicas (por número ou intervalo).
- Mesclar páginas de diferentes PDFs em um novo arquivo PDF.
"""

import os
from pypdf import PdfReader, PdfWriter


def get_pdf_bookmarks(pdf_path):
    """Lê um arquivo PDF e retorna uma lista de bookmarks (capítulos).

    Args:
        pdf_path (str): O caminho para o arquivo PDF.

    Returns:
        list: Uma lista de dicionários, onde cada dicionário representa um bookmark
              e contém 'title' (título do bookmark) e 'page_number' (número da página).
              Retorna uma lista vazia se não houver bookmarks ou em caso de erro.
    """
    bookmarks_info = []
    try:
        reader = PdfReader(pdf_path)
        for outline_item in reader.outline:
            # Acessar bookmarks de forma recursiva se necessário
            # Para simplificar, vamos pegar apenas os de primeiro nível por enquanto
            # A biblioteca pypdf pode ter diferentes formas de acessar os detalhes da página
            # dependendo da versão e da estrutura do PDF.
            # O objeto outline_item pode ser uma lista ou um Destination
            # Precisamos encontrar o número da página associado.
            # Esta parte pode precisar de ajuste dependendo de como pypdf retorna a página do outline_item
            try:
                # Tentar obter o número da página diretamente se o item for um destino
                # ou se tiver um atributo/método que forneça a página.
                # A documentação do pypdf sugere que reader.get_destination_page_number(outline_item) pode ser usado
                # mas outline_item em si pode não ser um Destination diretamente no loop.
                # Vamos assumir que outline_item.page (ou similar) pode existir ou que precisamos de uma função auxiliar.
                
                # Simplificação: pypdf trata outline_item como um objeto Destination ou uma lista de Destinations
                # Se for um objeto Destination, ele tem um atributo .page
                # Se for uma lista, precisamos iterar.
                
                def extract_bookmark_details(item, current_reader):
                    details = []
                    if isinstance(item, list): # É uma lista de sub-bookmarks
                        for sub_item in item:
                            details.extend(extract_bookmark_details(sub_item, current_reader))
                    else: # É um único bookmark (Destination object)
                        # O número da página em pypdf é 0-indexado, então adicionamos 1 para ser 1-indexado
                        page_num = current_reader.get_destination_page_number(item) + 1 
                        details.append({"title": item.title, "page_number": page_num})
                    return details

                bookmarks_info.extend(extract_bookmark_details(outline_item, reader))
                
            except Exception as e:
                print(f"Erro ao processar um bookmark: {e}")
                # Adicionar o título mesmo que a página não seja encontrada, para depuração
                if hasattr(outline_item, 'title'):
                    bookmarks_info.append({"title": outline_item.title, "page_number": -1}) 

    except Exception as e:
        print(f"Erro ao ler bookmarks do PDF {pdf_path}: {e}")
    return bookmarks_info

def extract_pages_from_pdf(pdf_path, page_ranges_str):
    """Extrai páginas específicas de um arquivo PDF com base em uma string de intervalos.

    Args:
        pdf_path (str): O caminho para o arquivo PDF fonte.
        page_ranges_str (str): Uma string especificando as páginas e/ou intervalos.
                               Ex: "1-5, 10, 12-15". As páginas são 1-indexadas.

    Returns:
        PdfWriter: Um objeto PdfWriter contendo as páginas extraídas, ou None em caso de erro.
    """
    if not os.path.exists(pdf_path):
        print(f"Arquivo PDF não encontrado: {pdf_path}")
        return None

    selected_pages = set()
    try:
        reader = PdfReader(pdf_path)
        total_pages_pdf = len(reader.pages)

        parts = page_ranges_str.split(',')
        for part in parts:
            part = part.strip()
            if '-' in part:
                start, end = map(int, part.split('-'))
                for i in range(start, end + 1):
                    if 1 <= i <= total_pages_pdf:
                        selected_pages.add(i - 1) # pypdf é 0-indexado
            else:
                page_num = int(part)
                if 1 <= page_num <= total_pages_pdf:
                    selected_pages.add(page_num - 1) # pypdf é 0-indexado
        
        if not selected_pages:
            print("Nenhuma página válida selecionada.")
            return None

        writer = PdfWriter()
        for page_index in sorted(list(selected_pages)):
            writer.add_page(reader.pages[page_index])
        return writer

    except Exception as e:
        print(f"Erro ao extrair páginas do PDF {pdf_path} com seleção '{page_ranges_str}': {e}")
        return None


def merge_pdfs(pdf_writers, output_path):
    """Mescla múltiplos objetos PdfWriter (contendo páginas) em um único arquivo PDF.

    Args:
        pdf_writers (list): Uma lista de objetos PdfWriter, cada um representando as páginas
                            a serem incluídas de uma fonte.
        output_path (str): O caminho para salvar o arquivo PDF mesclado.

    Returns:
        bool: True se a mesclagem for bem-sucedida, False caso contrário.
    """
    merged_writer = PdfWriter()
    try:
        for writer_obj in pdf_writers:
            if writer_obj:
                for page in writer_obj.pages: # Em pypdf >=3.0.0, writer.pages é uma lista de PageObject
                    merged_writer.add_page(page)
        
        if not merged_writer.pages:
            print("Nenhuma página para mesclar.")
            return False
            
        with open(output_path, "wb") as f_out:
            merged_writer.write(f_out)
        return True
    except Exception as e:
        print(f"Erro ao mesclar PDFs para {output_path}: {e}")
        return False

# Exemplo de uso (para teste local, remover ou comentar depois):
if __name__ == '__main__':
    # Suponha que você tenha PDFs de teste na mesma pasta
    # Teste de bookmarks
    # bookmarks = get_pdf_bookmarks("teste.pdf") 
    # print("Bookmarks:", bookmarks)

    # Teste de extração
    # writer1 = extract_pages_from_pdf("teste.pdf", "1-2")
    # writer2 = extract_pages_from_pdf("teste2.pdf", "1")

    # Teste de mesclagem
    # if writer1 and writer2:
    #     success = merge_pdfs([writer1, writer2], "mesclado.pdf")
    #     print("Mesclagem bem-sucedida:", success)
    # else:
    #     print("Falha na extração de um ou ambos os PDFs de teste.")
    print("Utilitários PDF carregados. Descomente as linhas de teste em __main__ para testar.")


