import os
import sys
import datetime # Adicionado para o ano atual

# Adds the project root directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, send_from_directory, render_template
from src.extensions import db, login_manager # Import from extensions

def create_app():
    app = Flask(__name__,
                static_folder=os.path.join(os.path.dirname(__file__), 'static'),
                template_folder=os.path.join(os.path.dirname(__file__), 'templates'))
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev_secret_key_12345_muito_segura')
    # Correção para usar instance_path para o banco de dados, garantindo que esteja na pasta instance
    instance_path = app.instance_path
    os.makedirs(instance_path, exist_ok=True) # Garante que a pasta instance exista
    db_path = os.path.join(instance_path, 'app.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    from src.models.user import User
    from src.models.page import Page, UserWorkbook # Apostilas originais (compiladas pelo usuário)
    from src.models.uploaded_workbook import UploadedWorkbook # Apostilas PDF fonte carregadas pelo admin

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Context processor para injetar o ano atual nos templates
    @app.context_processor
    def inject_current_year():
        return {'current_year': datetime.datetime.now().year}

    from src.routes.auth_routes import auth_bp
    from src.routes.main_routes import main_bp
    from src.routes.workbook_routes import workbook_bp
    from src.routes.admin_routes import admin_bp # Novas rotas administrativas
    from src.routes.custom_compiler_routes import custom_compiler_bp # Novas rotas de compilação
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(main_bp)
    app.register_blueprint(workbook_bp, url_prefix='/workbook')
    app.register_blueprint(admin_bp, url_prefix='/admin') # Registrar blueprint admin
    app.register_blueprint(custom_compiler_bp, url_prefix='/custom_compiler') # Registrar blueprint de compilação

    with app.app_context():
        db.create_all()

    # Movido para o final para não interceptar blueprints
    # @app.route('/<path:path>')
    # def serve_static_files(path):
    #     static_folder_path = app.static_folder
    #     if static_folder_path and os.path.exists(os.path.join(static_folder_path, path)):
    #         return send_from_directory(static_folder_path, path)
    #     if os.path.exists(os.path.join(app.template_folder, "404.html")):
    #         return render_template("404.html"), 404
    #     else:
    #         return "File not found", 404
            
    return app

app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003, debug=True)