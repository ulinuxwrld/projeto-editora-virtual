# -*- coding: utf-8 -*-
"""
Modelo de dados para Apostilas Fonte (PDFs carregados pelo administrador).
"""
from src.extensions import db
from datetime import datetime

class UploadedWorkbook(db.Model):
    __tablename__ = "uploaded_workbook"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    original_filename = db.Column(db.String(200), nullable=False)
    # Caminho relativo à pasta de uploads configurada, ex: "source_pdfs/meu_arquivo.pdf"
    filepath_relative = db.Column(db.String(300), nullable=False, unique=True) 
    total_pages = db.Column(db.Integer, nullable=False)
    # Armazena os bookmarks detectados como uma string JSON.
    bookmarks_json = db.Column(db.Text, nullable=True) 
    
    uploaded_by_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    uploaded_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    # Relação com User (quem fez o upload)
    # Assumindo que o modelo User está definido em src.models.user
    uploader = db.relationship('User', backref=db.backref('uploaded_workbooks', lazy='dynamic'))

    def __repr__(self):
        return f'<UploadedWorkbook {self.id}: {self.title}>'

