# src/models/page.py
from src.extensions import db  # Alterado para importar de src.extensions

class Page(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    subject = db.Column(db.String(100), nullable=True)
    grade_level = db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return f'<Page {self.title}>'

class UserWorkbook(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False, default='Minha Apostila Personalizada')
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    selected_page_ids = db.Column(db.Text, nullable=True)
    is_purchased = db.Column(db.Boolean, default=False)
    pdf_file_path = db.Column(db.String(300), nullable=True)

    user = db.relationship('User', backref=db.backref('workbooks', lazy=True))

    def __repr__(self):
        return f'<UserWorkbook {self.id} - User {self.user_id}>'

